import express from "express";
import { loadServerConfig } from "./config/env.js";
import { RateLimitedCache } from "./cache/rateLimitedCache.js";
import { validateProxyQuery } from "./validators/payloadValidator.js";
import { adaptUpstreamSnapshot } from "./adapters/footballAdapter.js";

const config = loadServerConfig();
const cache = new RateLimitedCache({
  ttlMs: config.cacheTtlMs,
  maxRequests: config.rateLimitMax,
  windowMs: config.rateLimitWindowMs,
});

const app = express();
app.use(express.json());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", config.allowedOrigin);
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

app.use((req, res, next) => {
  const clientKey = req.ip || req.headers["x-forwarded-for"] || "unknown";
  if (!cache.allowRequest(String(clientKey))) {
    return res.status(429).json({
      status: "ERROR",
      message: "Rate limit exceeded on CardRadar backend proxy.",
    });
  }
  next();
});

app.get("/health", (_req, res) => {
  if (!config.hasCredentials) {
    return res.status(503).json({
      status: "UNAVAILABLE",
      provider: config.providerName,
      credentialsConfigured: false,
      message: "LIVE DATA NOT CONNECTED: Server provider credentials are not configured.",
    });
  }

  return res.status(200).json({
    status: "CONNECTED",
    provider: config.providerName,
    credentialsConfigured: true,
    timestamp: new Date().toISOString(),
  });
});

app.get("/api/v1/football-proxy", async (req, res) => {
  const parsedQuery = validateProxyQuery(req.query);
  if (!parsedQuery.ok) {
    return res.status(400).json({
      status: "ERROR",
      message: parsedQuery.error,
    });
  }

  if (!config.hasCredentials) {
    return res.status(503).json({
      status: "UNAVAILABLE",
      message: "LIVE DATA NOT CONNECTED: Configure FOOTBALL_DATA_BASE_URL and FOOTBALL_DATA_API_KEY on the server.",
    });
  }

  const { resource, season, competition } = parsedQuery.value;
  const cacheKey = `football:${config.providerName}:${competition}:${season}:${resource}`;
  const cached = cache.get(cacheKey);
  if (cached) {
    return res.status(200).json({ ...cached, cached: true });
  }

  try {
    const upstreamUrl = new URL(`${config.baseUrl}/snapshot`);
    upstreamUrl.searchParams.set("season", season);
    upstreamUrl.searchParams.set("competition", competition);
    upstreamUrl.searchParams.set("resource", resource);

    const upstreamRes = await fetch(upstreamUrl.toString(), {
      headers: {
        Authorization: `Bearer ${config.apiKey}`,
        Accept: "application/json",
      },
    });

    if (!upstreamRes.ok) {
      return res.status(502).json({
        status: "ERROR",
        message: `Upstream provider returned HTTP ${upstreamRes.status}.`,
      });
    }

    const rawJson = await upstreamRes.json();
    const normalized = adaptUpstreamSnapshot(rawJson, { season, competition });
    const responseBody = {
      status: "CONNECTED",
      cached: false,
      data: normalized,
    };

    cache.set(cacheKey, responseBody);
    return res.status(200).json(responseBody);
  } catch (err) {
    return res.status(502).json({
      status: "ERROR",
      message: `Upstream fetch failure: ${err instanceof Error ? err.message : "Unknown error"}`,
    });
  }
});

app.listen(config.port, () => {
  console.log(`CardRadar backend listening on port ${config.port}`);
});
