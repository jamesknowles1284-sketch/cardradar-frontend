import { validateNormalizedPayload } from "../validators/payloadValidator.js";

export function adaptUpstreamSnapshot(rawUpstreamData, { season, competition }) {
  const rawFixtures = Array.isArray(rawUpstreamData?.fixtures) ? rawUpstreamData.fixtures : [];
  const rawPlayers = Array.isArray(rawUpstreamData?.players) ? rawUpstreamData.players : [];
  const rawReferees = Array.isArray(rawUpstreamData?.referees) ? rawUpstreamData.referees : [];

  const fixtures = rawFixtures.map((f, idx) => ({
    id: String(f.id ?? `live-fix-${idx}`),
    round: String(f.round ?? f.matchday ?? ""),
    kickoff: String(f.kickoff ?? f.date ?? ""),
    venue: String(f.venue ?? ""),
    referee: String(f.referee ?? ""),
    homeTeam: String(f.homeTeam ?? f.home_team ?? ""),
    awayTeam: String(f.awayTeam ?? f.away_team ?? ""),
    homeFoulsPer90: Number(f.homeFoulsPer90 ?? 0),
    awayFoulsPer90: Number(f.awayFoulsPer90 ?? 0),
    projectedYellows: Number(f.projectedYellows ?? 0),
    projectedReds: Number(f.projectedReds ?? 0),
    riskScore: Number(f.riskScore ?? 0),
    riskLevel: String(f.riskLevel ?? "LOW"),
    watchlist: Array.isArray(f.watchlist) ? f.watchlist : [],
  }));

  const players = rawPlayers.map((p, idx) => {
    const minutesPlayed = Number(p.minutesPlayed ?? p.minutes ?? 0);
    const yellowCards = Number(p.yellowCards ?? p.yellow_cards ?? 0);
    const redCards = Number(p.redCards ?? p.red_cards ?? 0);
    const foulsCommittedPer90 = Number(p.foulsCommittedPer90 ?? p.fouls_committed_per_90 ?? 0);
    const foulsDrawnPer90 = Number(p.foulsDrawnPer90 ?? p.fouls_drawn_per_90 ?? 0);

    return {
      id: String(p.id ?? `live-plr-${idx}`),
      name: String(p.name ?? ""),
      club: String(p.club ?? p.team ?? ""),
      position: String(p.position ?? ""),
      yellowCards,
      redCards,
      foulsCommittedPer90,
      foulsDrawnPer90,
      minutesPlayed,
      indicatorScore: Number(p.indicatorScore ?? 0),
      riskLevel: String(p.riskLevel ?? "LOW"),
      recentForm: Array.isArray(p.recentForm) ? p.recentForm : [],
      foulBreakdown: p.foulBreakdown ?? { tactical: 34, aerial: 22, lateChallenge: 24, dissent: 20 },
      lastFiveMatches: Array.isArray(p.lastFiveMatches) ? p.lastFiveMatches : [],
    };
  });

  const referees = rawReferees.map((r, idx) => ({
    id: String(r.id ?? `live-ref-${idx}`),
    name: String(r.name ?? ""),
    matchesOfficiated: Number(r.matchesOfficiated ?? r.matches ?? 0),
    yellowsPerGame: Number(r.yellowsPerGame ?? r.yellows_per_game ?? 0),
    redsPerGame: Number(r.redsPerGame ?? r.reds_per_game ?? 0),
    foulsPerGame: Number(r.foulsPerGame ?? r.fouls_per_game ?? 0),
    cardsPerFoulPct: Number(r.cardsPerFoulPct ?? 0),
    homeYellowShare: Number(r.homeYellowShare ?? 50),
    awayYellowShare: Number(r.awayYellowShare ?? 50),
    strictnessLabel: String(r.strictnessLabel ?? "STANDARD"),
  }));

  const validated = validateNormalizedPayload({ fixtures, players, referees });

  return {
    ...validated,
    season,
    competition,
    updatedAt: new Date().toISOString(),
  };
}
