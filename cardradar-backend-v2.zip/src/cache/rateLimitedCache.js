export class RateLimitedCache {
  constructor({ ttlMs = 60_000, maxRequests = 60, windowMs = 60_000 }) {
    this.ttlMs = ttlMs;
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    this.store = new Map();
    this.clientHits = new Map();
  }

  allowRequest(clientKey) {
    const now = Date.now();
    const timestamps = (this.clientHits.get(clientKey) || []).filter(
      (ts) => now - ts < this.windowMs
    );

    if (timestamps.length >= this.maxRequests) {
      this.clientHits.set(clientKey, timestamps);
      return false;
    }

    timestamps.push(now);
    this.clientHits.set(clientKey, timestamps);
    return true;
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.value;
  }

  set(key, value, customTtlMs = this.ttlMs) {
    this.store.set(key, {
      value,
      expiresAt: Date.now() + customTtlMs,
    });
  }
}
