const ALLOWED_RESOURCES = new Set(["fixtures", "players", "referees", "snapshot"]);
const ALLOWED_SEASONS = new Set(["2026/27", "2025/26", "2024/25"]);
const ALLOWED_COMPETITIONS = new Set(["PL", "EFLC", "FAC"]);

export function validateProxyQuery(query) {
  const resource = String(query.resource || "snapshot").trim();
  const season = String(query.season || "2026/27").trim();
  const competition = String(query.competition || "PL").trim();

  if (!ALLOWED_RESOURCES.has(resource)) {
    return { ok: false, error: `Unsupported resource '${resource}'.` };
  }
  if (!ALLOWED_SEASONS.has(season)) {
    return { ok: false, error: `Unsupported season '${season}'.` };
  }
  if (!ALLOWED_COMPETITIONS.has(competition)) {
    return { ok: false, error: `Unsupported competition '${competition}'.` };
  }

  return { ok: true, value: { resource, season, competition } };
}

function isNonNegativeNumber(val) {
  return typeof val === "number" && Number.isFinite(val) && val >= 0;
}

export function validateNormalizedPayload(payload) {
  if (!payload || typeof payload !== "object") {
    throw new Error("Normalized payload must be an object.");
  }

  const fixtures = Array.isArray(payload.fixtures) ? payload.fixtures : null;
  const players = Array.isArray(payload.players) ? payload.players : null;
  const referees = Array.isArray(payload.referees) ? payload.referees : null;

  if (!fixtures || !players || !referees) {
    throw new Error("Payload must contain fixtures, players, and referees arrays.");
  }

  for (const p of players) {
    if (
      typeof p.id !== "string" ||
      typeof p.name !== "string" ||
      !isNonNegativeNumber(p.yellowCards) ||
      !isNonNegativeNumber(p.redCards) ||
      !isNonNegativeNumber(p.foulsCommittedPer90) ||
      !isNonNegativeNumber(p.foulsDrawnPer90) ||
      !isNonNegativeNumber(p.minutesPlayed)
    ) {
      throw new Error(`Invalid player record for ${p?.name || "unknown"}`);
    }
  }

  for (const r of referees) {
    if (
      typeof r.id !== "string" ||
      typeof r.name !== "string" ||
      !isNonNegativeNumber(r.yellowsPerGame) ||
      !isNonNegativeNumber(r.redsPerGame) ||
      !isNonNegativeNumber(r.foulsPerGame)
    ) {
      throw new Error(`Invalid referee record for ${r?.name || "unknown"}`);
    }
  }

  for (const f of fixtures) {
    if (
      typeof f.id !== "string" ||
      typeof f.homeTeam !== "string" ||
      typeof f.awayTeam !== "string"
    ) {
      throw new Error(`Invalid fixture record for ${f?.id || "unknown"}`);
    }
  }

  return {
    sourceType: "LIVE_DATA",
    verified: true,
    fixtures,
    players,
    referees,
  };
}
