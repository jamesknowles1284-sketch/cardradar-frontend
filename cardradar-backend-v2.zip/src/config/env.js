export function loadServerConfig() {
  const apiKey = process.env.FOOTBALL_DATA_API_KEY?.trim() || "";
  const baseUrl = (process.env.FOOTBALL_DATA_BASE_URL || "").trim().replace(/\/+$/, "");
  const providerName = (process.env.FOOTBALL_DATA_PROVIDER || "unconfigured").trim();
  const allowedOrigin = (process.env.ALLOWED_ORIGIN || "*").trim();
  const port = Number(process.env.PORT || 8787);
  const cacheTtlMs = Number(process.env.CACHE_TTL_MS || 60_000);
  const rateLimitMax = Number(process.env.RATE_LIMIT_MAX || 60);
  const rateLimitWindowMs = Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000);

  return {
    port,
    providerName,
    baseUrl,
    apiKey,
    allowedOrigin,
    hasCredentials: Boolean(apiKey && baseUrl),
    cacheTtlMs,
    rateLimitMax,
    rateLimitWindowMs,
  };
}
